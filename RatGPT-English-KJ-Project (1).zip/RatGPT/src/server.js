import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');
const dataPath = path.join(projectRoot, 'data', 'kj-vocabulary.json');
const app = express();
const PORT = Number.parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const AI_PROVIDER = (process.env.AI_PROVIDER || 'ollama').toLowerCase();
const OLLAMA_BASE_URL = (process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434').replace(/\/+$/, '');
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.2:3b';
const AI_BASE_URL = (process.env.AI_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/+$/, '');
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'llama-3.3-70b-versatile';

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'"], scriptSrc: ["'self'"],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"],
  baseUri: ["'self'"], frameAncestors: ["'none'"]
}}}));
app.use(morgan('tiny'));
app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.join(projectRoot, 'public')));

async function readDictionary() {
  try { return JSON.parse(await fs.readFile(dataPath, 'utf8')); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const empty = { vocabulary: [], phrases: [], verses: [] };
    await fs.writeFile(dataPath, JSON.stringify(empty, null, 2), 'utf8');
    return empty;
  }
}
async function writeDictionary(data) {
  await fs.writeFile(dataPath, JSON.stringify(data, null, 2), 'utf8');
}

app.get('/api/health', async (_req, res) => {
  if (AI_PROVIDER === 'compatible') {
    const ready = Boolean(AI_API_KEY);
    return res.status(ready ? 200 : 503).json({ ok:ready, ollama:ready, model:AI_MODEL, modelAvailable:ready, provider:'Hosted AI', message:ready ? 'Hosted AI is configured.' : 'Set AI_API_KEY in the hosting environment.' });
  }
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) return res.status(503).json({ ok:false, ollama:false, model:OLLAMA_MODEL, modelAvailable:false, provider:'Ollama', message:'Ollama is not responding normally.' });
    const payload = await response.json();
    const models = Array.isArray(payload.models) ? payload.models.map(x => x.name) : [];
    const modelAvailable = models.some(name => name === OLLAMA_MODEL || name.startsWith(`${OLLAMA_MODEL.split(':')[0]}:`));
    res.json({ ok:true, ollama:true, model:OLLAMA_MODEL, modelAvailable, provider:'Ollama', installedModels:models });
  } catch {
    res.status(503).json({ ok:false, ollama:false, model:OLLAMA_MODEL, modelAvailable:false, provider:'Ollama', message:'Cannot reach Ollama. For online hosting, configure AI_PROVIDER=compatible and AI_API_KEY.' });
  }
});
app.get('/api/kj', async (_req, res, next) => {
  try { res.json(await readDictionary()); } catch (e) { next(e); }
});

app.post('/api/kj/words', async (req, res, next) => {
  try {
    const kj = typeof req.body?.kj === 'string' ? req.body.kj.trim() : '';
    const en = typeof req.body?.en === 'string' ? req.body.en.trim() : '';
    const category = typeof req.body?.category === 'string' ? req.body.category.trim().slice(0,60) : 'Unsorted';
    const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0,500) : '';
    if (!kj || !en || kj.length > 120 || en.length > 240) return res.status(400).json({ error:'Enter a KJ word and its English meaning (within the character limits).' });
    const data = await readDictionary();
    const existing = data.vocabulary.findIndex(x => x.kj.toLocaleLowerCase() === kj.toLocaleLowerCase());
    const item = { kj, en, category:category || 'Unsorted', confidence:'Added by learner', notes };
    if (existing >= 0) data.vocabulary[existing] = item; else data.vocabulary.push(item);
    await writeDictionary(data);
    res.json({ ok:true, item, count:data.vocabulary.length });
  } catch (e) { next(e); }
});

app.post('/api/kj/phrases', async (req, res, next) => {
  try {
    const kj = typeof req.body?.kj === 'string' ? req.body.kj.trim() : '';
    const en = typeof req.body?.en === 'string' ? req.body.en.trim() : '';
    const reference = typeof req.body?.reference === 'string' ? req.body.reference.trim().slice(0,100) : '';
    if (!kj || !en || kj.length > 2000 || en.length > 2000) return res.status(400).json({ error:'Enter both the KJ text and English meaning/translation.' });
    const data = await readDictionary();
    data.verses.push({ kj, en, reference, addedAt:new Date().toISOString(), source:'User-provided; not independently verified' });
    await writeDictionary(data);
    res.json({ ok:true, count:data.verses.length });
  } catch (e) { next(e); }
});

app.post('/api/chat', async (req, res) => {
  const { messages, mode = 'english' } = req.body ?? {};
  if (!Array.isArray(messages) || !messages.length || messages.length > 40) return res.status(400).json({ error:'Send between 1 and 40 chat messages.' });
  const safeMessages = [];
  for (const item of messages) {
    if (!item || !['user','assistant'].includes(item.role) || typeof item.content !== 'string') return res.status(400).json({ error:'Each message needs a valid role and text content.' });
    const content = item.content.trim();
    if (!content || content.length > 6000) return res.status(400).json({ error:'Messages must contain 1–6000 characters.' });
    safeMessages.push({ role:item.role, content });
  }
  const data = await readDictionary().catch(() => ({ vocabulary:[], phrases:[], verses:[] }));
  const vocabContext = data.vocabulary.map(x => `${x.kj} = ${x.en}${x.notes ? ` (note: ${x.notes})` : ''}`).join('\n');
  const phraseContext = data.phrases.map(x => `${x.kj} = ${x.en}`).join('\n');
  const verseContext = data.verses.slice(-30).map(x => `${x.reference ? x.reference+': ' : ''}KJ: ${x.kj}\nEnglish: ${x.en}`).join('\n\n');
  const modeInstructions = {
    english: 'Answer mainly in English. When useful, teach one relevant KJ word from the supplied dictionary and clearly label it.',
    learn: 'Act as a patient KJ language tutor for Ngkaramajong nolo Ngdodoth. Teach using only the supplied KJ dictionary, phrases, and user-provided verse bank. Clearly distinguish confirmed entries from entries marked for verification. Do not invent KJ words, grammar, or Bible translations. If information is missing, say so and ask the learner or teacher to provide/correct it. Explain in English unless the learner asks otherwise.',
    kj: 'Use KJ only where the supplied vocabulary supports it, and otherwise explain in English that the dictionary is incomplete. Do not fabricate translations or pretend to be fluent. Ask the learner to correct uncertain forms.'
  }[mode] || 'Answer mainly in English and support KJ learning using the supplied dictionary.';
  const systemPrompt = `You are RatGPT, an English + Ngkaramajong nolo Ngdodoth (KJ) learning assistant. ${modeInstructions}
Important dialect rules supplied by the learner:
- “Lokal” is the spelling for “house”; do not write “local” for that word.
- The learner says “Ary” comes before a noun; preserve this rule and do not generalize beyond examples they have confirmed.
- “Etau” means “heart” in this dialect. Do not translate “Etau nolo Asegan” as “Holy Spirit”.
- Use “Ekuam nolo Asegan” for the learner's Holy Spirit phrase.
- “Yesu ca ecal” means “Jesus and the family”; use “ca” in that phrase.
- Preserve the distinction: angupi = believe (singular); tongup = believe (group/plural); tongupak = “believe!” command to a group.
Source policy: The supplied vocabulary and verse bank are learner-provided reference data, not a complete or independently verified dictionary. Never invent a Bible verse or claim a translation is verified when it is not. For Bible passages, work from text the user provides and note that spelling/translation should be checked with a knowledgeable KJ speaker or the user's Bible edition.
KJ dictionary:
${vocabContext || '(no entries yet)'}
Known phrases:
${phraseContext || '(no phrases yet)'}
User-provided Bible/phrase bank:
${verseContext || '(no Bible text has been added yet)'}
Be friendly, clear, encouraging, and honest.`;
  try {
    let reply = '';
    let usedModel = OLLAMA_MODEL;
    if (AI_PROVIDER === 'compatible') {
      if (!AI_API_KEY) return res.status(503).json({ error:'Hosted AI is not configured yet. The site owner must add AI_API_KEY in the hosting settings.' });
      usedModel = AI_MODEL;
      const response = await fetch(`${AI_BASE_URL}/chat/completions`, {
        method:'POST',
        headers:{ 'Content-Type':'application/json', 'Authorization':`Bearer ${AI_API_KEY}` },
        body:JSON.stringify({ model:AI_MODEL, messages:[{role:'system',content:systemPrompt},...safeMessages], temperature:0.7, max_tokens:1200 }),
        signal:AbortSignal.timeout(120000)
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) return res.status(502).json({ error:payload.error?.message || payload.error || `Hosted AI returned HTTP ${response.status}.` });
      reply = payload.choices?.[0]?.message?.content || '';
    } else {
      const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ model:OLLAMA_MODEL, messages:[{role:'system',content:systemPrompt},...safeMessages], stream:false }),
        signal:AbortSignal.timeout(120000)
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) return res.status(502).json({ error:payload.error || `Ollama returned HTTP ${response.status}.` });
      reply = payload.message?.content || '';
      usedModel = payload.model || OLLAMA_MODEL;
    }
    if (typeof reply !== 'string' || !reply.trim()) return res.status(502).json({ error:'The model returned an empty reply. Try again.' });
    res.json({ reply:reply.trim(), model:usedModel });
  } catch (error) {
    const timedOut = error?.name === 'TimeoutError' || error?.name === 'AbortError';
    res.status(503).json({ error:timedOut ? 'The model took too long. Try a shorter message.' : (AI_PROVIDER === 'compatible' ? 'Cannot connect to the hosted AI provider. Check the provider URL and API key.' : 'Cannot connect to Ollama. Make sure Ollama is running and the model is downloaded.') });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof SyntaxError && 'body' in err) return res.status(400).json({ error:'Invalid JSON request body.' });
  console.error('Unexpected server error:', err);
  res.status(500).json({ error:'Unexpected server error.' });
});
app.listen(PORT, HOST, () => console.log(`RatGPT is running at http://${HOST}:${PORT} (model: ${OLLAMA_MODEL})`));
