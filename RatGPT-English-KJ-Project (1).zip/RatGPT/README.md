# RatGPT — English + Ngkaramajong nolo Ngdodoth (KJ)

RatGPT is a small full-stack web app with an English/KJ learning chat, searchable vocabulary, flashcards, and a user-provided Bible/phrase bank.

## Quickest way to make it available to friends

This project is prepared for Render, which can host the Node.js website. **You still need to create the hosting account and deploy it yourself**; this package cannot publish to a public account automatically.

1. Create a GitHub account if you do not already have one, then create a new repository named `ratgpt`.
2. Upload the contents of this ZIP into the repository (upload the files inside the folder, not an extra wrapper folder).
3. Create a Render account and choose **New + → Blueprint**. Connect the GitHub repository containing `render.yaml`.
4. When Render asks for `AI_API_KEY`, provide a secret API key from a compatible hosted AI provider. The sample defaults are configured for Groq's OpenAI-compatible API, but model availability and free-tier limits can change. A provider account/API key is required for hosted AI; do not put the key in browser JavaScript or commit it to GitHub.
5. Deploy. When the build finishes, Render will give you a public `https://...onrender.com` URL that you can send to friends.

If you want to use a different compatible provider, change `AI_BASE_URL`, `AI_MODEL`, and `AI_API_KEY` in the Render environment settings to that provider's current documented values.

## Important free-hosting limits

- The Render free web service can sleep after inactivity and may take a little while to wake up.
- The free service does not provide durable storage by default. New words and Bible passages added while the app is running may be lost after a restart/redeploy. The included starter dictionary is in `data/kj-vocabulary.json`.
- The model provider may impose rate limits or change its free tier. A hosted model is not guaranteed to remain free forever.
- The app has not been deployed to a public host from this workspace. Test the deployed URL before sharing it widely.

## Run on your own computer

Requires Node.js 20+ and (for local AI) Ollama.

```bash
npm install
cp .env.example .env
ollama pull llama3.2:3b
ollama serve
npm start
```

Open `http://localhost:3000`. On Windows, you can copy `.env.example` to `.env` using File Explorer instead of `cp`.

To use hosted AI locally, set `AI_PROVIDER=compatible`, set `AI_BASE_URL`, `AI_MODEL`, and `AI_API_KEY` in `.env`, then restart the server. Keep `.env` private.

## KJ accuracy notes

The seeded vocabulary reflects learner-provided entries and corrections. It is not a complete or independently verified dictionary. RatGPT is instructed to flag uncertainty instead of inventing KJ words or claiming that Bible translations have been verified. Add text and translations from the exact KJ Bible edition you use, and have uncertain entries checked by a knowledgeable speaker.
